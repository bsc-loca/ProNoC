/**************************************
* Module: router_bypass
* Date:2020-11-24  
* Author: alireza     
*
* Description: 
*   This file conyains Verilog modules that can be added
*   to a 3-stage NoC router and provide router bypassing
***************************************/

/**************************
 * SBP_flags_gen:
 * generate SBP flags based on NoC parameter, current router's port and address,
 * and destination router address
 * located in router output port
 * spb_flag_o indicates how many more router in direct line can be bypassed
 * 
 ***************************/
module SBP_flags_gen_per_oport #(
    //SBP parameters
    parameter SBP_NUM =4,
    //NoC other parameters
    parameter TOPOLOGY          =   "MESH", 
    parameter ROUTE_NAME        =   "XY",
    parameter ROUTE_TYPE        =   "DETERMINISTIC", 
    parameter MAX_P             =   6,
    parameter T1                =   4,
    parameter T2                =   4,
    parameter T3                =   2,
    parameter RAw               =   3,  
    parameter EAw               =   3,   
    parameter DSTPw             =   4, 
    parameter SPB_OPORT_NUM     =   0 // output switch number 
)
(   
    reset,
    clk,
    dest_e_addr ,
	src_e_addr,
    current_r_addr,
    spb_routers_in,
    spb_routers_out,
    spb_flag_o    
);   



    function integer log2;
    input integer number; begin   
       log2=(number <=1) ? 1: 0;    
       while(2**log2<number) begin    
          log2=log2+1;    
       end        
    end   
    endfunction // log2 
  
    input   reset,clk;          
    input   [RAw-1   :0] current_r_addr;    
   
    input   [EAw-1   :0] src_e_addr,dest_e_addr;
	input   [RAw-1   :0] spb_routers_in  [SBP_NUM-1 : 0];
	output 	[RAw-1   :0] spb_routers_out [SBP_NUM-1 : 0];
	
    output  [SBP_NUM-1 : 0] spb_flag_o;	    
    wire   [MAX_P-1 :0] spb_oports [SBP_NUM-1 : 0];
    
    //generate the spb_routers_out for other routers
    //constant router address gen 
    assign spb_routers_out[0]=current_r_addr;
    genvar i;
    generate 
    for (i=1; i<SBP_NUM; i=i+1) begin :lp1 
    	assign spb_routers_out[i]  = spb_routers_in[i-1];    	
	end	
	
    //Conventional-routing loop
   	for (i=0; i<SBP_NUM; i=i+1) begin :lp2 
   		
   		
   		
   				   
   		router_outputport_predict #(
   			.TOPOLOGY        (TOPOLOGY       ), 
   			.ROUTE_NAME      (ROUTE_NAME     ), 
   			.ROUTE_TYPE      (ROUTE_TYPE     ), 
   			.MAX_P           (MAX_P          ), 
   			.DSTPw           (DSTPw          ), 
   			.T1              (T1             ), 
   			.T2              (T2             ), 
   			.T3              (T3             ), 
   			.RAw             (RAw            ), 
   			.EAw             (EAw            ),
   			.SPB_OPORT_NUM   (SPB_OPORT_NUM  )
   		) 
		router_outputport_predict 
   		(
   			.current_r_addr  (spb_routers_in[i] ), 
   			.src_e_addr      (src_e_addr     ), 
   			.dest_e_addr     (dest_e_addr    ), 
   			.router_portout  (spb_oports[i] ),
			.reset(reset),
			.clk(clk)
   		);
   		if(i!=0) begin 
   			assign spb_flag_o[i]= (spb_oports[i][SPB_OPORT_NUM] & spb_flag_o[i-1]); 	
   		end	
   		
   		
   	end	
   	
   	assign spb_flag_o[0] = spb_oports[i][SPB_OPORT_NUM];
   	
    endgenerate	

endmodule

/******************
 *  get packet source/destination address and generate the possible 
 *  current router output port number as one-hot code 
 * ****************/
 
module router_outputport_predict  #(
		parameter TOPOLOGY          =   "MESH", 
		parameter ROUTE_NAME        =   "XY",
		parameter ROUTE_TYPE        =   "DETERMINISTIC", 
		parameter MAX_P             =   6, // max port num in a router in the topology
		parameter DSTPw             =   4,
		parameter T1                =   4,
		parameter T2                =   4,
		parameter T3                =   2,
		parameter RAw 				=   3,  
		parameter EAw				=   3, 
		parameter SPB_OPORT_NUM     =   1
    
		)
		(   
		current_r_addr,
		src_e_addr,
		dest_e_addr,
		router_portout,
		lk_dest_port,
		reset,
		clk
		);  


	function integer log2;
		input integer number; begin   
			log2=(number <=1) ? 1: 0;    
			while(2**log2<number) begin    
				log2=log2+1;    
			end        
		end   
	endfunction // log2 
  
	input  reset,clk;          
	input   [RAw-1   :0] current_r_addr;
	input   [EAw-1   :0] src_e_addr;
	input   [EAw-1   :0] dest_e_addr;
	output  [MAX_P-1 :0] router_portout;
	output  [DSTPw-1 : 0] lk_dest_port;
	
	wire [DSTPw-1 : 0] dest_port_coded;
	ni_conventional_routing #(
			.TOPOLOGY        (TOPOLOGY       ), 
			.ROUTE_NAME      (ROUTE_NAME     ), 
			.ROUTE_TYPE      (ROUTE_TYPE     ), 
			.T1              (T1             ), 
			.T2              (T2             ), 
			.T3              (T3             ), 
			.RAw             (RAw            ), 
			.EAw             (EAw            ), 
			.DSTPw           (DSTPw          )
		) the_ni_conventional_routing (
			.reset           (reset          ), 
			.clk             (clk            ), 
			.current_r_addr  (current_r_addr), 
			.current_e_addr  (src_e_addr    ),
			.dest_e_addr     (dest_e_addr    ), 
			.destport        (dest_port_coded)
		); 

        
	localparam   
		NL = T3,
		ELw = log2(NL);    // number of node in y axis
        
	generate 
	/* verilator lint_off WIDTH */ 
		if(TOPOLOGY == "MESH" || TOPOLOGY == "TORUS"  || TOPOLOGY ==  "RING" || TOPOLOGY ==  "LINE") begin :mesh_torus  
			localparam  P = (TOPOLOGY == "MESH" || TOPOLOGY == "TORUS")?  5:3;
			/* verilator lint_on WIDTH */ 
    
			if(NL==1) begin :single_lp    
           
				if( ROUTE_TYPE == "DETERMINISTIC") begin :dtrmn
					assign router_portout[P-1 : 1] = dest_port_coded;
					assign router_portout[0]= ~(|dest_port_coded); 
					
					//predict receiver port from SPB_OPORT_NUM
					mesh_torus_next_router_inport_predictor #(
							.TOPOLOGY(TOPOLOGY),
							.P(P)
						)
						inport_predictor
						(
							.destport(destport_one_hot),
							.receive_port(receive_port)
						);
					// remove receiver port from router_portout
					lk_dest_port 
					
				end // dtrmn
				else begin : adptv1
					reg [4:0] portout;
					wire x,y,a,b;
					assign {x,y,a,b} = dest_port_coded;
                    assign lk_dest_port = dest_port_coded;    
					always @(*)begin 
						case({a,b})
							2'b10 : portout = {1'b0,~x,1'b0,x,1'b0};
							2'b01 : portout = {~y,1'b0,y,1'b0,1'b0};
							2'b11 : portout = {~y,~x,y,x,1'b0};
							2'b00 : portout =  5'b00001;
						endcase
					end //always
                
					assign router_portout = portout;     
                
				end //adaptive
			end //single_lp 
			else begin : multi_lp
         
				wire [ELw-1 : 0] endp_l_bin;
				wire [NL-1  : 0] endp_l_one_hot;
                
				mesh_tori_endp_addr_decode #(
						.TOPOLOGY("MESH"),
						.T1(T1),
						.T2(T2),
						.T3(T3),
						.EAw(EAw)
					)
					endp_addr_decode
					(
						.e_addr(dest_e_addr),
						.ex( ),
						.ey( ),
						.el(endp_l_bin),
						.valid( )
					);
                
				bin_to_one_hot #(
						.BIN_WIDTH      (  ELw   ), 
						.ONE_HOT_WIDTH  (  NL   )
					) 
					conv
					(
						.bin_code       (endp_l_bin      ), 
						.one_hot_code   (endp_l_one_hot )
					);
         
         
				if( ROUTE_TYPE == "DETERMINISTIC") begin :dtrmn
					wire [NL-1 : 0] endp_l_one_hot_valid = ~(|dest_port_coded)? endp_l_one_hot : {NL{1'b0}};                
					assign router_portout = {endp_l_one_hot_valid[NL-1 : 1], dest_port_coded,  endp_l_one_hot_valid[0]};
				
					
				end // dtrmn
				else begin : adptv2
					reg [4:0] portout;
					wire x,y,a,b;
					assign {x,y,a,b} = dest_port_coded;
                    assign dest_port_coded = dest_port_coded;    
					always @(*)begin 
						case({a,b})
							2'b10 : portout = {1'b0,~x,1'b0,x,1'b0};
							2'b01 : portout = {~y,1'b0,y,1'b0,1'b0};
							2'b11 : portout = {~y,~x,y,x,1'b0};
							2'b00 : portout =  5'b00001;
						endcase
					end //always
                
					wire [NL-1 : 0] endp_l_one_hot_valid = (portout[0])? endp_l_one_hot : {NL{1'b0}};              
					assign router_portout = {endp_l_one_hot_valid[NL-1 : 1], portout[P-1 : 1],  endp_l_one_hot_valid[0]};    
        
                
				end//adaptive
			end//multi
           
            
      
		end//mesh_torus 
		//TODO add fattree and custom
	endgenerate

  
endmodule


/***********************************
 *      oport_conventional_routing
 * *********************************/
//routing module that can be located in output ports. (used in SPB)
module  conventional_routing  #(
		parameter TOPOLOGY          =   "MESH", 
		parameter ROUTE_NAME        =   "XY",
		parameter ROUTE_TYPE        =   "DETERMINISTIC", 
		parameter T1                =   4,
		parameter T2                =   4,
		parameter T3                =   4,
		parameter RAw = 3,  
		parameter EAw = 3,   
		parameter DSTPw=4,
		parameter SW_LOC    =1
		)
		(   
		reset,
		clk,
		current_r_addr,
		current_e_addr,
		dest_e_addr,
		destport
		);    

	function integer log2;
		input integer number; begin   
			log2=(number <=1) ? 1: 0;    
			while(2**log2<number) begin    
				log2=log2+1;    
			end        
		end   
	endfunction // log2 
        
		
	
	input  reset,clk;          
	input   [RAw-1   :0] current_r_addr;
	input   [EAw-1   :0] current_e_addr;
	input   [EAw-1   :0] dest_e_addr;
	output  [DSTPw-1 :0] destport;
    
	genvar i;
	generate 
	/* verilator lint_off WIDTH */ 
		if(TOPOLOGY == "MESH" || TOPOLOGY == "TORUS"  || TOPOLOGY ==  "RING" || TOPOLOGY ==  "LINE")begin :mesh_torus
			/* verilator lint_on WIDTH */ 
     
			localparam
				NX = T1,
				NY = T2,
				RXw = log2(NX),   
				RYw = log2(NY),  
				EXw = RXw,
				EYw = RYw;
        
			wire   [RXw-1   :   0]  current_rx;
			wire   [RYw-1   :   0]  current_ry;                  
			wire   [EXw-1   :   0]  dest_ex;
			wire   [EYw-1   :   0]  dest_ey;
        
			localparam 
			/* verilator lint_off WIDTH */ 
				P = (TOPOLOGY == "MESH" || TOPOLOGY == "TORUS")?  5:3,
			/* verilator lint_on WIDTH */ 
				SL_SW_LOC = ( SW_LOC > P-T3) ? 0 : SW_LOC, //single_local
				LOCATED_IN_NI = (SL_SW_LOC ==0 ) ? 1 : 0,
				DSTw     =   (ROUTE_TYPE ==   "DETERMINISTIC")? P : P_1; 
         
				wire [DSTw -1 : 0] destport_not_coded;
			
				mesh_torus_conventional_routing #(
					.TOPOLOGY(TOPOLOGY),
					.ROUTE_NAME(ROUTE_NAME),
					.ROUTE_TYPE(ROUTE_TYPE),
					.P(P),
					.NX(NX),
					.NY(NY),
					.LOCATED_IN_NI(LOCATED_IN_NI)
				)
				conventional
				(
					.current_x(current_x),
					.current_y(current_y),
					.dest_x(dest_x),
					.dest_y(dest_y),
					.destport(destport_not_coded)
        
				);
				
				mesh_torus_next_router_inport_predictor #(
						.TOPOLOGY(TOPOLOGY),
						.P(P)
					)
					inport_predictor
					(
						.destport(destport_not_coded),
						.receive_port(receive_port)
					);
				
				remove_receive_port_one_hot #(
						.P(P)
					)
					remove_receive_port_one_hot(
						.destport_in(destport_not_coded),
						.receiver_port(receive_port),
						.destport_out(destport)
					);		
			
		
				
		end else begin 
			ni_conventional_routing #(
					.TOPOLOGY        (TOPOLOGY       ), 
					.ROUTE_NAME      (ROUTE_NAME     ), 
					.ROUTE_TYPE      (ROUTE_TYPE     ), 
					.T1              (T1             ), 
					.T2              (T2             ), 
					.T3              (T3             ), 
					.RAw             (RAw            ), 
					.EAw             (EAw            ), 
					.DSTPw           (DSTPw          )
				) conventional_routing (
					.reset           (reset          ), 
					.clk             (clk            ), 
					.current_r_addr  (current_r_addr), 
					.current_e_addr  (src_e_addr    ),
					.dest_e_addr     (dest_e_addr    ), 
					.destport        (dest_port_coded)
				); 
			
		end	
		endgenerate

endmodule



		
