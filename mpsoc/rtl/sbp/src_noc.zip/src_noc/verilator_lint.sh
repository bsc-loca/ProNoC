#!/bin/bash
echo "filelist: $1";
export workspace_loc="$1/.."
verilator --lint-only  --cc  --top-module "SBP_flags_gen"   --profile-cfuncs --prefix "Vnoc" -O3  -CFLAGS -O3 -f $1/sve.f -y ${workspace_loc}/src_noc/
