
`ifdef     INCLUDE_TEST_LOCALPARAM


localparam REPEAT_NUM=10000000;

    localparam 
      	//NoC param
	DEBUG_EN=1,
	T1 = 4,
        T2 = 4,
        T3 = 3,
	T4 = 1,
	B  = 15,
	TOPOLOGY="MESH",
	ROUTE_NAME="XY",


	//agent nums
        SYS_CACHE_EN=1,
        NUM_OF_RNs=16,
        NUM_OF_HNs=16,
        NUM_OF_SNs=2,
       
	//snf param
	SNPF_WAY_NUM = 8,
        SNPF_ADDRw   = 44,
        SNPF_INDEXw  = 10,
        CACHE_WAY_NUM= 8,
        CACHE_INDEXw =10,

	//pck-injector 	
	WRAP_REQ_W=64,

	//snf param 
	MEM_RD_PIPE_LATENCY =50,
        MEM_WR_PIPE_LATENCY =500;



    localparam VERBOSITY = 0
    //  | MONITORE_FLIT_INJECT
    //  | MONITORE_FLIT_INJECT_FILEDS
    //  | MONITORE_TXN_CMD 
    //  | MONITORE_WAIT_LIST
    //  | MONITORE_CACHE 
    //  | MONITORE_SNPF 
    //  | MONITORE_TXNID_GEN 
    //  | MONITORE_MAIN_MEM 
    //  | MONITORE_REQ_TYPE
    //  | MONITORE_EXCL_TXN
       |0;

 /* verilator lint_off WIDTH */
 localparam 
        MAX_HNFs_ASSIGND_TO_A_SN = (NUM_OF_HNs  / NUM_OF_SNs) + ((NUM_OF_HNs  % NUM_OF_SNs)>0);
/* verilator lint_on WIDTH */
 
	integer  file [NUM_OF_RNs-1 : 0];
	


	

	reg  [NUM_OF_RNs-1 : 0] injct_done;


	


	

`endif
